package com.example.chapter05;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Self0501_org extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.self0501_main_org);
    }
}
